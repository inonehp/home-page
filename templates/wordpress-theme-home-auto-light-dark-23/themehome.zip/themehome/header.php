<!DOCTYPE html>
<?php
if (empty($title)){ $title = get_the_title(); }
if (empty($desc)){ $desc = get_bloginfo('description'); }
?>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">

<title><?php echo $title; ?></title>

<meta name="description" content="
<?php echo $desc; ?>
">
<meta name="keywords" content="
">

<?php
$logo = "";
if (function_exists('the_custom_logo')){
//the_custom_logo();
$custom_logo_id = get_theme_mod('custom_logo');
$logo = wp_get_attachment_image_src($custom_logo_id);
//print_r($logo);
if (!empty($logo[0])){ $logo = $logo[0]; };
}
?>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!--<link rel="icon" href="<?=$logo?>" type="image/png">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">-->

<!-- wp_head -->
<?php wp_head(); ?>
<!-- // wp_head -->

<noscript>
<link rel="stylesheet" type="text/css" href="<?php bloginfo('url'); ?>/wp-content/themes/themehome/assets/css/noscript.css">
</noscript>

</head>
<body <?php /*body_class();*/ ?>>

<!-- top -->

<!-- Nav v.1.2.1 -->
<!-- page, style.css, main.js, noscript.css -->

<!-- nav HTML part -->
<header>
<div class="wrapper3 navTop">
<div class="margin"></div>
<nav>

<a class="countMenuItem inlineBlock padding" style="padding-left: 0;" href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?> (nav)"><img class="logo2 reduceLight" src="<?php echo $logo; ?>" alt="logo" style="max-width: 26px;"></a> 

<div class="menuTop">
<!-- menu items -->
<!--<a class="countMenuItem brand borderBottomTransparent inlineBlock padding" href="/main-list.php">Main</a>
<a class="countMenuItem brand borderBottomTransparent inlineBlock padding" href="/projects-page.php">Projects</a>
<a class="countMenuItem brand borderBottomTransparent inlineBlock padding" href="/games-list.php">Games</a>-->
<?php
wp_nav_menu(
array(
'menu' => 'primary',
'container' => '',
'theme_location' => 'primary',
'items_wrap' => '<ul>%3$s</ul>'
)
);
?>
<!-- // menu items -->

</div>
<!-- // menuTop -->

<!-- dropdown menu -->
<!-- https://www.w3schools.com/howto/howto_js_dropdown.asp -->
<div id="dropdownMenuCSS"><!-- CSS menu if js off -->
<button onclick="dropdownMenuFunction();" class="brand inlineBlock padding" id="dropdownMenuButton">☰ Menu</button>
<div id="dropdownMenu" class="dropdownMenuContent shadow bg2 padding2 borderRadius2">
<div class="dropdownMenuWrapper">
<!--<div class="padding2">menu name</div>-->
<div class="dropdownMenuContentColumn">

<!-- menu items dublicate -->
<!--<a class="countMenuItem brand borderBottomTransparent inlineBlock padding" href="/main-list.php">Main</a>
<a class="countMenuItem brand borderBottomTransparent inlineBlock padding" href="/projects-page.php">Projects</a>
<a class="countMenuItem brand borderBottomTransparent inlineBlock padding" href="/games-list.php">Games</a>-->
<?php
wp_nav_menu(
array(
'menu' => 'primary',
'container' => '',
'theme_location' => 'primary',
'items_wrap' => '<ul>%3$s</ul>'
)
);
?>
<!-- // menu items dublicate -->

</div>
</div>
</div>
</div>
<!--<hr />-->
<!-- // dropdown menu -->

<span class="countMenuItem"></span>
<span class="countMenuItem"></span>
<!--<a class="countMenuItem inlineBlock padding mClassNavUp brand" style="margin-right: var(--padding);" href="../" title="../Up">List (↑)</a>-->
<form class="inlineBlock padding"  style="padding-right: 0;" method="GET" action="<?php bloginfo('url'); ?>" role="search">
<!--<label for="siteSearch" class="xSmall op">search:</label>-->
<input id="siteSearch" type="search" placeholder="site search" name="s" autocomplete="off">
</form>

</nav>
</div>
</header>
<!-- // nav -->

<!--<hr>-->
<!-- // top -->

<!-- content -->
<main class="content">
<div class="wrapper2">

<!--<h1 class="op tCenter"><?php echo $title; ?></h1>-->
<div class="margin padding"></div>

