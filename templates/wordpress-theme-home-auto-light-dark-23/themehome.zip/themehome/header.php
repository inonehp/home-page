<!DOCTYPE html>
<?php
if (empty($title)){ $title = get_the_title(); }
if (empty($desc)){ $desc = get_bloginfo('description'); }
?>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">

<title><?php echo $title; ?></title>

<meta name="description" content="
<?php echo $desc; ?>
">
<meta name="keywords" content="
">

<?php
$logo = "";
if (function_exists('the_custom_logo')){
//the_custom_logo();
$custom_logo_id = get_theme_mod('custom_logo');
$logo = wp_get_attachment_image_src($custom_logo_id);
//print_r($logo);
if (!empty($logo[0])){ $logo = $logo[0]; };
}
?>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!--<link rel="icon" href="<?=$logo?>" type="image/png">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">-->

<!-- wp_head -->
<?php wp_head(); ?>
<!-- // wp_head -->

<noscript>
<link rel="stylesheet" type="text/css" href="<?php bloginfo('url'); ?>/wp-content/themes/themehome/assets/css/noscript.css">
</noscript>

</head>
<body <?php /*body_class();*/ ?>>

<!-- top -->


<!-- Navigation HTML part v.1.0.0 -->
<header>
<div class="wrapper3">
<div class="margin2"></div>

<div id="topNav" class="topNav">
<nav>

<span class="countMenuItem"></span>
<a class="countMenuItem inlineBlock padding brand" style="padding-left: 0;" href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?> (nav)"><img class="logo2 reduceLight" src="<?php echo $logo; ?>" alt="logo" style="max-width: 26px;"></a> 

<div class="dropdownMenuContentWrapper">
<div class="dropdownMenuContent">

<a id="dropdownMenuButton" class="dropdownMenuButton inlineBlock padding mClassNavUp brand borderBottomTransparent itemLinkAni" href="#" onclick="fuMDropdownButton();return false;">☰ Menu</a>

<span id="navMenu" class="navMenu">
<!-- links in nav -->
<?php
wp_nav_menu(
array(
'menu' => 'primary',
'container' => '',
'theme_location' => 'primary',
'items_wrap' => '<ul>%3$s</ul>'
)
);
?>
<!-- // links in nav -->
</span>


<span id="dropdownMenu" class="dropdownMenu">
<div class="dropdownMenuColumn shadow bg2 padding2 borderRadius2">
<!-- links for show in dropdown (duplicate) -->
<?php
wp_nav_menu(
array(
'menu' => 'primary',
'container' => '',
'theme_location' => 'primary',
'items_wrap' => '<ul>%3$s</ul>'
)
);
?>
<!-- // links for show in dropdown (duplicate) -->
</div>
</span>

</div>
</div>

<span class="countMenuItem"></span>
<form class="countMenuItem noscriptHide inlineBlock padding" style="padding-right: 0;" method="GET" action="/main/site-search.<?=$ext?>" role="search">
<!--<label for="siteSearch" class="xSmall op">search:</label>-->
<input id="siteSearch" type="search" placeholder="site search" name="q" autocomplete="off">
</form>

</nav>
</div>

</div>
</header>
<!-- // Navigation HTML -->



<?php
/*wp_nav_menu(
array(
'menu' => 'primary',
'container' => '',
'theme_location' => 'primary',
'items_wrap' => '<ul>%3$s</ul>'
)
);*/
?>
<!--<hr>-->
<!-- // top -->

<!-- content -->
<main class="content">
<div class="wrapper2">

<!--<h1 class="op tCenter"><?php echo $title; ?></h1>-->
<div class="margin padding"></div>

