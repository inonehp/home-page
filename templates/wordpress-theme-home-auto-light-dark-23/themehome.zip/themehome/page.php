<?php
get_header();
?>

<!-- page: page.php -->

<?php
if (have_posts()){
while (have_posts()){
the_post();
//the_content();

get_template_part('template-parts/content', 'page');
}
}






?>

<div class="padding2 margin2"></div>

</main>
<!-- // content -->

<?php
get_footer();
?>
