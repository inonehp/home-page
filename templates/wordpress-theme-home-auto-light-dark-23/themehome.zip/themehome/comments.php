
<!-- page: comments.php -->

<hr>

<div class="padding2 margin2"></div>

<?php



if (!have_comments()){
///echo "Leave a Comment";
} else {
echo get_comments_number()." Comments:<br><br>";
}

wp_list_comments(
array(
'avatar_size' => 32,
'style' => 'ul',
)
);


if (comments_open()){
comment_form(
array(
'class_form' => '',
'title_reply_before' => '<hr><h2 id="reply-title" class="comment-reply-title">',
'title_reply_after' => '</h2>'
)
);
}
?>
