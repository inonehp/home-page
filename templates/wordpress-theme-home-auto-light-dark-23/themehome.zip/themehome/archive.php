<?php
get_header();
?>

<!-- page: archive.php -->
<h1 class="op tCenter">Archive</h1>

<?php
if (have_posts()){
while (have_posts()){
the_post();
//the_content();
get_template_part('template-parts/content', 'archive');
}
}
?>

<div class="padding margin"></div>
<?php the_posts_pagination(); ?>

<?php
if (!is_page()){
?>
<div class="padding2 margin2"></div>
<div class="center">
<div class="tagList">
<?php wp_tag_cloud( array(
   'smallest' => 8, // size of least used tag
   'largest'  => 22, // size of most used tag
   'unit'     => 'px', // unit for sizing the tags
   'number'   => 45, // displays at most 45 tags
   'orderby'  => 'name', // order tags alphabetically
   'order'    => 'ASC', // order tags by ascending order
   'taxonomy' => 'post_tag' // you can even make tags for custom taxonomies
) );
?>
</div>
</div>
<div class="margin2 padding2"></div>
<?php
}
?>

<?php
get_footer();
?>
