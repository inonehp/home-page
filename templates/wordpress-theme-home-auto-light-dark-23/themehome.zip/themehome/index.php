<?php
get_header();
?>

<!-- page: index.php (fornt-page.php) -->

<?php
/*
if (have_posts()){
while (have_posts()){
the_post();
the_content();
}
}*/

if (!is_page()){
echo '<h1 class="op tCenter">Blog</h1>';
}

//https://stackoverflow.com/questions/69542331/display-custom-posts-in-custom-template-in-wordpress
if (have_posts()){
while (have_posts()) {
the_post(); 

$link = get_permalink();
//https://stackoverflow.com/questions/4290420/wordpress-how-to-check-whether-it-is-post-or-page
$time = "";
$commentsNumber = get_comments_number();
if (!is_page()){
$time = get_the_date();
$time = <<<EOF
<a class="block tRight" href="$link">$time ($commentsNumber)</a>
EOF;
}

//<div>'.apply_filters('get_the_excerpt', get_the_excerpt()).'</div>
//<div class="featured-image">'.the_post_thumbnail().'</div>
//<div>'.apply_filters('the_content', get_the_content()).'</div>
//wpdocs_show_tags()

echo '
<div class="bgList border3List borderRadius2 padding3 tLeft">
<h2><a href="'.$link.'">'.get_the_title().'</a></h2>
<div>'.apply_filters('the_content', get_the_content()).'</div>
';
?>

<div class="postFooter break2 small">
<span class="tagList tLeft left"><?php echo the_category( ', ' ).the_tags('<span> / ', ', ', '</span>'); ?></span>
<span class="tagList tRight right"><?php echo $time ?></span>
</div>

<?php
echo '</div>';

}
}

/*
function wpdocs_show_category(){
$categories = get_the_category();
$separator = ' ';
$output = '';
if ( ! empty( $categories ) ) {
	foreach( $categories as $category ) {
		$output .= '<a class="brand tag" href="' . esc_url( get_category_link( $category->term_id ) ) . '" alt="' . esc_attr( sprintf( __( 'View all posts in %s', 'textdomain' ), $category->name ) ) . '">[ ' . esc_html( $category->name ) . ' ]</a>' . $separator;
	}
	echo trim( $output, $separator );
}
}

//https://developer.wordpress.org/reference/functions/get_the_tags/
function wpdocs_show_tags() {
    $post_tags = get_the_tags();
    $separator = ' ';
    $output = '';

    if ( ! empty( $post_tags ) ) {
        foreach ( $post_tags as $tag ) {
            $output .= '<a class="brand tag" href="' . esc_attr( get_tag_link( $tag->term_id ) ) . '">' . __( $tag->name ) . '</a>' . $separator;
        }
    }

    return trim( $output, $separator );
}*/


?>




//https://developer.wordpress.org/reference/functions/get_the_tags/
function wpdocs_show_tags() {
    $post_tags = get_the_tags();
    $separator = ' ';
    $output = '';

    if ( ! empty( $post_tags ) ) {
        foreach ( $post_tags as $tag ) {
            $output .= '<a href="' . esc_attr( get_tag_link( $tag->term_id ) ) . '">' . __( $tag->name ) . '</a>' . $separator;
        }
    }

    return trim( $output, $separator );
}


?>

<div class="padding margin"></div>
<?php the_posts_pagination(); ?>

<?php
if (!is_page()){
?>
<div class="margin2 padding2"></div>
<div class="center">
<div class="tagList">
<?php wp_tag_cloud( array(
   'smallest' => 8, // size of least used tag
   'largest'  => 22, // size of most used tag
   'unit'     => 'px', // unit for sizing the tags
   'number'   => 45, // displays at most 45 tags
   'orderby'  => 'name', // order tags alphabetically
   'order'    => 'ASC', // order tags by ascending order
   'taxonomy' => 'post_tag' // you can even make tags for custom taxonomies
) );
?>
</div>
</div>
<div class="margin2 padding2"></div>
<?php
}
?>



<?php get_footer(); ?>
