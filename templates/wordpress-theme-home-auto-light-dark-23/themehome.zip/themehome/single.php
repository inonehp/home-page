<?php
get_header();
?>

<!-- page: single.php -->
<h1 class="op tCenter">Post</h1>

<?php
if (have_posts()){
while (have_posts()){
the_post();
//the_content();
get_template_part('template-parts/content', 'article');
}
}
?>

<?php
get_footer();
?>

