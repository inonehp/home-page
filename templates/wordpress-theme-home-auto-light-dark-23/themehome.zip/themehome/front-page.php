<?php
get_header();
?>

<!-- page: front-page.php (index.php) -->

<?php
/*
if (have_posts()){
while (have_posts()){
the_post();
the_content();
}
}*/

if (!is_page()){
echo '<h1 class="op tCenter">Blog</h1>';
}

//https://stackoverflow.com/questions/69542331/display-custom-posts-in-custom-template-in-wordpress
if (have_posts()){
while (have_posts()) {
the_post(); 

$img = "";
/*
//https://wordpress.stackexchange.com/questions/22965/how-to-get-images-included-in-post
$args = array( 
    'post_type' => 'attachment', 
    'post_mime_type' => 'image',
    'numberposts' => -1, 
    'post_status' => null, 
    'post_parent' => $post->ID 
); 
$attached_images = get_posts($args);
$array = json_decode(json_encode($attached_images), true);
if (isset($array[0]["guid"])){ $img = $array[0]["guid"]; }
if (!empty($img)){
$img =  <<<EOF
<img src="$img" alt="img">
EOF;
}*/

$link = get_permalink();
//https://stackoverflow.com/questions/4290420/wordpress-how-to-check-whether-it-is-post-or-page
$time = "";
$commentsNumber = get_comments_number();
if (!is_page()){
$time = get_the_date();
$time = <<<EOF
<a class="block tRight" href="$link">$time ($commentsNumber)</a>
EOF;
}

//<div class="featured-image">'.the_post_thumbnail().'</div>
//<div>'.apply_filters('the_content', get_the_content()).'</div>
echo '
<div class="bgList border3List borderRadius2 padding3 tLeft">
<h2><a href="'.$link.'">'.get_the_title().'</a></h2>
'.$img.'
<div>'.apply_filters('get_the_excerpt', get_the_excerpt()).'</div>
';
?>

<div class="postFooter break2 small">
<span class="tagList tLeft left"><?php echo wpdocs_show_tags(); ?></span>
<span class="tagList tRight right"><?php echo $time ?></span>
</div>

<?php
echo '</div>';

}
}




//https://developer.wordpress.org/reference/functions/get_the_tags/
function wpdocs_show_tags() {
    $post_tags = get_the_tags();
    $separator = ' ';
    $output = '';

    if ( ! empty( $post_tags ) ) {
        foreach ( $post_tags as $tag ) {
            $output .= '<a href="' . esc_attr( get_tag_link( $tag->term_id ) ) . '">' . __( $tag->name ) . '</a>' . $separator;
        }
    }

    return trim( $output, $separator );
}


?>

<div class="padding margin"></div>
<?php the_posts_pagination(); ?>

<?php
if (!is_page()){
?>
<div class="margin2 padding2"></div>
<div class="center">
<div class="tagList">
<?php wp_tag_cloud( array(
   'smallest' => 8, // size of least used tag
   'largest'  => 22, // size of most used tag
   'unit'     => 'px', // unit for sizing the tags
   'number'   => 45, // displays at most 45 tags
   'orderby'  => 'name', // order tags alphabetically
   'order'    => 'ASC', // order tags by ascending order
   'taxonomy' => 'post_tag' // you can even make tags for custom taxonomies
) );
?>
</div>
</div>
<div class="margin2 padding2"></div>
<?php
}
?>


<?php get_footer(); ?>
