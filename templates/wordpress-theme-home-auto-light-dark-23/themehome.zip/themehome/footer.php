
<!-- page: footer.php -->

</div>
</main>

<footer class="tCenter margin3List">
<div class="margin3 padding3"></div>
<nav>

<?php
//dynamic_sidebar('sidebar-1');
?>

<a class="padding brand" style="padding-left: 0;" href="<?php bloginfo('rss2_url'); ?>" title="<?php _e('Syndicate this site using RSS'); ?>"><?php _e('<abbr title="Really Simple Syndication">RSS</abbr>'); ?></a>
<!--<a class="padding brand" href="#">link example</a>
<a class="padding brand" href="#">link example</a>-->
<span class="op padding small" style="padding-right: 0;">2024</span>
</nav>
</footer>

<?php
wp_footer();
?>

</body>
</html>
