<?php
$title = "Page Not Found";

get_header();
?>

<!-- page: 404.php -->

<h1 class="op tCenter">Page Not Found</h1>

<div class="margin2 padding2"></div>

<?php 
get_search_form();
?>

<?php
get_footer();
?>
