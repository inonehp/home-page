
<h1 class="op tCenter"><?php the_title(); ?></h1>

<?php

the_content();

//the_date();


?>
