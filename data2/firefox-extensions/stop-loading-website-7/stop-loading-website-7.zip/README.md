

Stop loading the site from the specified list of sites in the extension settings. The extension works based on how the browser's stop button works. 
