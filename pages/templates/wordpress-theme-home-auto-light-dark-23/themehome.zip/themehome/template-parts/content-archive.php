
<?php
/*
the_post_thumbnail_url();
*/


/*
the_title();
the_excerpt();

the_date();
comments_number();
the_permalink();

comments_template();
*/

$link = get_permalink();
//https://stackoverflow.com/questions/4290420/wordpress-how-to-check-whether-it-is-post-or-page
$time = "";
$commentsNumber = get_comments_number();
if (!is_page()){
$time = get_the_date();
$time = <<<EOF
<a class="block tRight" href="$link">$time <span title="Comments">($commentsNumber)</span></a>
EOF;
}


?>

<article>
<div class="bgList border3List borderRadius2 padding3 tLeft">
<h2><a href="<?=$link?>"><?php the_title(); ?></a></h2>
<?php
//the_excerpt();
the_content();
?>

<div class="postFooter break2 small">
<span class="tagList tLeft left"><?php the_category( ', ' ).the_tags('<span> / ', ', ', '</span>'); ?></span>
<span class="tagList tRight right"><?php echo $time; ?></span>
</div>

</div>
</article>

<?php
/*<div class="padding smaller gray"><?php comments_number(); ?></div>*/
//comments_number();
//comments_template();
?>
